#!/bin/bash
create_file()
{
echo "Input the file name you want to create -"
read fname
a=ls|grep "$fname"
if [[ $fname -eq $a ]]
then
	echo "File already exists"
else
	touch $fname
fi
}

create_dir()
{
echo "Input the directory name you want to create -"
read dname
b=ls|grep "$dname"
if [[ $dname -eq $b ]] 
then
	echo "Directory already  EXISTSS !!! "
else
	mkdir $dname
fi
}

echo -e " Input\n 1 for creating a file \n 2 for directory \n 3 for Copying a file \n 4 for moving a file "
read ch

case "$ch" in
	"1") create_file
	;;
	"2")create_dir
	;;
	*)echo "INVALID !!!"
	;;
esac
