#!/bin/bash

echo "give three number"
read n1
read n2
read n3

echo $n1>ass.txt
echo $n2>ass.txt
echo $n3>ass.txt

sort -n ass.txt

