#!/bin/bash

echo "Give three number to print  in ascending order"

read n1
read n2
read n3
echo "ascending order of given three numer is "
if [ $n1 -lt $n2 ] && [ $n1 -lt $n3 ]
then 
	echo $n1
	if [ $n2 -lt $n3 ]
	then
		echo $n2
		echo $n3
	else
		echo $3
		echo $2
	fi
else  
	if [ $n2 -lt $n3 ] && [ $n2 -lt $n1 ]
	then
		echo $n2
		if [ $n3 -lt $n1 ]
		then
			echo $n3
			echo $n1

		else
			echo $n1
			echo $n3

		fi

	else 
		echo $n3
		if [ $n2 -lt $n1 ]
		then
			echo $n2 
			echo $n1

		else
			echo $n1
			echo $n2
		fi
	fi			
fi

