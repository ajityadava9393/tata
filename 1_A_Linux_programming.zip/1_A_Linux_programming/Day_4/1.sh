#!/bin/bash

echo "This is our first script">>dbda.txt

