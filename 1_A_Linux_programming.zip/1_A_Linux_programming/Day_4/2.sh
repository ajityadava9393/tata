#!/bin/bash
chmod 777 dbda.txt
