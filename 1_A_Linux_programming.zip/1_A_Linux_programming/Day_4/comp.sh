
#!/bin/bash
echo "give tow number to compare"

read n1
read n2
if [ $n1 -eq $n2 ]

then
	echo "numbers are equal"
else
	echo "numbers are not equal"
fi

echo "out of if"
