#! /bin/bash

echo "give  number to print largest and samllest number"
read num1
read num2

if [ $num1 -gt $num2 ]

then
	 echo "grater number is " $num1
	echo "samller number is " $num2
else 
	echo "grater number is " $num2
	echo "samller number is " $num1
fi

