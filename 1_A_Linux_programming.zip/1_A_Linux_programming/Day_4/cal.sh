#! /bin/bash

echo "entre two number"
 read num1
read num2

echo "you have entered these two number"
echo $num1
echo $num2

add=`expr $num1 + $num2`

echo "additio of two number is" $add

sub=`expr $num1 - $num2`

echo "subutra  is " $sub

malti=`expr $num1 \* $num2`

echo "multi is" $malti

div=`expr $num1 / $num2`

echo "div is" $div

rem=`expr $num1 % $num2`
 echo "rem is" $rem 
