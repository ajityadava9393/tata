#! /bin/bash
echo "Enter any number to khow whether it is even or odd"
read num
if [ `expr $num % 2` -eq 0 ]
then 
	echo "number is even"
else
	echo "number is odd"
fi
