#!/bin/bash
 echo " enter three numbers "
read n1
read n2
read n3
if [ $n1 -gt $n2 ]
then
echo " enter three numbers "
	if [ $n1 -gt $n3 ]
	then
		if [ $n2 -gt $n3 ]
		then
			echo  $n3
			echo  $n2
			echo  $n1
		else
			echo $n2
			echo $n3
			echo $n1
		fi
	fi
else
	if [ $n1 -lt $n3 ]
	then
		if [ $n2 -lt $n3 ]
		then
			echo $n1
			echo $n2
			echo $n3
		else
			echo $n1
			echo $n3
			echo $n2
		fi
	else
		if [ $n1 -gt $n2 ]
		then
			if [ $n2 -gt $n3 ]
			then
				echo $n3 $n2 $n1
			else
				echo $n2 $n3 $n1
			fi
		fi
	fi
fi
