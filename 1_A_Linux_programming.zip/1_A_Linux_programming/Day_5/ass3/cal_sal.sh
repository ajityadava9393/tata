#!/bin/bash

echo "give basic salary to calcute net salary"

read basic

dp=`echo " $basic * 0.5"|bc `

sal=`echo " $basic + $dp + ($dp + $basic) * 0.35 + ($dp + $basic) * 0.08 + ($dp + $basic) * 0.03 - ($dp + $basic) * 0.1"|bc `
echo "Your Net Salary is" $sal
