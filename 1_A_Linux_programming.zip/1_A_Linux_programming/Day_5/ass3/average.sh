#!/bin/bash
echo "Enter  any three numbers whose average you want to calculate"
read n1
read n2
read n3
avg=`echo " scale=5; ($n1 + $n2 + $n3)/3"|bc `
echo $avg   
