#!/bin/bash
echo "Enter any two numbers"
read n1
read n2
echo "scale=2; $n1 + $n2"|bc 
