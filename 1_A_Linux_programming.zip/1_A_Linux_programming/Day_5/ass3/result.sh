#!/bin/bash

echo "give marks out of 100 of three subject to see  average marks"

read m1
read m2
read m3

avg=` echo " scale=2; ($m1 + $m2 + $m3) / 3 "|bc `

if [ $avg -gt 50 ]
then
	echo "first class with " $avg
	
else
	if [ [ $avg -ge 40 ] && [ $avg -le 50 ] ]
	then
	echo "second class with" $avg
	
	else
	echo "fail and you got" $avg
	fi
fi

