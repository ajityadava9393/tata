#!/bin/bash

echo "Give your principle amt"
read P
echo "Give rate of interest"
read R
echo "Give time duration in Years"
read T
I=`expr $P \* $R  \* $T / 100`
echo "Your simple interest is" $I

I=`echo " $P * $R  * $T * 0.01 "|bc `
 echo "i2" $I
