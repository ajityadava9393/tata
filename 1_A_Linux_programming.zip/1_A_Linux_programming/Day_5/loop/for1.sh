#!/bin/bash
for((i=4; i<=20; i++))
do
	echo $i
done
