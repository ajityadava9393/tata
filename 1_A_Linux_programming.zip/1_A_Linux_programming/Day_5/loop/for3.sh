#!/bin/bash
for i in 1 2 3 
do 
	echo "welcome $i"
done
