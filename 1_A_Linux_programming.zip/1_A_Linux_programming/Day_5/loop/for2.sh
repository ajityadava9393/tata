#!/bin/bash
for i in {4..20..2}
do 
	echo $i
done

