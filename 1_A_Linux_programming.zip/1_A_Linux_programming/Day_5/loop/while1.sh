#!/bin/bash
i=0
while [ $i -lt 10 ]
do 
	echo "roll number $i"
	i=`expr $i + 1`
done

