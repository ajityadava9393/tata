#!/bin/bash
echo "Enter any number n to display odd numbers and their sum"
read num
sum=0
z=`expr $num \* 2`
for (( i=1; i<=$z; i = $i + 2 ))
do
	echo -ne "$i\t"
	sum=`expr $sum + $i`
done
echo
echo "sum=$sum"

