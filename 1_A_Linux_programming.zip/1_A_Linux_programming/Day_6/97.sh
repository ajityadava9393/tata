#!/bin/bash
echo "Give marks of 5 subjects Phy Che Bio Math Comp"
read P
read C
read B
read M
read Co
total=`expr $P + $C + $B + $M + $Co`
per=`expr $total / 5`
if [ $per -ge 90 ]
then
	echo "Grade A"
elif [ $per -ge 80 ] && [ $per -lt 90 ]
then
	echo "Grade B"
elif [ $per -ge 70 ] && [ $per -lt 80 ]
then
        echo "Grade C"
elif [ $per -ge 60 ] && [ $per -lt 70 ]
then
        echo "Grade D"
elif [ $per -ge 40 ] && [ $per -lt 60 ]
then
        echo "Grade E"
else
	echo "Grade F"
fi




