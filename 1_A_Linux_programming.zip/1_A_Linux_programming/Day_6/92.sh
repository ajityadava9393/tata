#!/bin/bash
echo "Give any 3 number to find max number"
read x
read y
read z
if [ $x -gt $y ] && [ $x -gt $z ]
then 
	echo " maximum number = $x"
elif [ $y -gt $x ] && [ $y -gt $z ] 
then
	 echo " maximum number = $y"
else
         echo " maximum number = $z"
fi


