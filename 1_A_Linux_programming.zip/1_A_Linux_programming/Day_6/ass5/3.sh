#!/bin/bash
echo "Enter any number"
read num
sum=0
for (( i=1; i<=$num; i++))
do
	echo -ne "\t $i"
	sum=`expr $sum + $i` 
done

echo
echo  "The Sum is " $sum

