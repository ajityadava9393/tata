#!/bin/bash
echo "sum of First 10 nathural numbers"
sum=0
for (( i=1; i<=10; i++))
do
sum=`expr $sum + $i` 
done
echo "The Sum is " $sum
