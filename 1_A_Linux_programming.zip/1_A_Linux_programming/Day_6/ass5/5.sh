#!/bin/bash
echo "Enter any number"
read num
for (( i=1; i<=$num; i++))
do
	cube=`expr $i \* $i \* $i`
	echo "Number is $i and cube of the $i is $cube"
done

