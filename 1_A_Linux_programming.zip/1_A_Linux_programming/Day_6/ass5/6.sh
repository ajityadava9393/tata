#!/bin/bash
echo "Enter your numberto print table"
read num
for (( i=1; i<=10; i++))
do
	cube=`expr $i \* $num`
	echo "$num X $i = $cube"
done

