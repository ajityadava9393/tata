#!/bin/bash
echo "Enter any 10 number"

sum=0
for (( i=1; i<=10; i++))
do
	read num
	sum=`expr $sum + $num`
done
echo -e "\nsum= $sum" 

avg=`echo "scale=2;$sum / 10"|bc`
echo "avg="$avg
