#!/bin/bash
echo "First 10 nathural numbers"
for (( i=1; i<=10; i++))
do
	echo -ne "\t $i"
done

