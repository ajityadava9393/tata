 #!/bin/bash
echo "Enter any number n to print table from 1 to n"
read num
for (( i=1; i<=$num; i++))
do
	for (( j=1; j<=10; j++))
	do
	        echo -n "$j X $i = `expr $i \* $j`,"
	done
        echo -e "\n" 
   
done

