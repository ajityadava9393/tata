#!/bin/bash

echo "Enter any number n to display odd numbers and their sum"
read  num
j=1
sum=0
for (( i=1; i<=$num; i++ ))
do
	echo -n "  $j"
	sum=`expr $sum + $j`
	j=`expr $j + 2`	
done 

echo -e "\n  The Sum of odd Natural Number up to $num terms : $sum"
