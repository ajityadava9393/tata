#!/bin/bash
echo "Give your number to cheak whaether it is leap year or not"
read n

if [[ ( `expr $n % 4` -eq 0 ) && ( `expr $n % 100` -ne 0 ) ]] || [ `expr $n % 400` -eq 0 ]
then
	echo " Given year is a leap year"
else
	echo " Given year is not a leap year"
fi
