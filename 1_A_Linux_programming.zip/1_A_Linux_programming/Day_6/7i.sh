 #!/bin/bash
echo "Enter any number n to print table from 1 to n"
read num
for (( j=1; j<=10; j++ ))
do
	for (( i=1; i<=$num; i++))
	do
	        echo -n "$i X $j = `expr $i \* $j`,"
	done
        echo -e "\n" 
   
done
