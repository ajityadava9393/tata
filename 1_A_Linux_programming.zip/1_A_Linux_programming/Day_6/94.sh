#!/bin/bash
echo "Enter any number to check whether it is divisible by 5 and 11 or not"
read n
if [ `expr $n % 5` -eq 0 ] && [ `expr $n % 11` -eq 0 ]
then 
	echo "$n is divisible by 5 and 11"
else
	echo "$n is not  divisible by 5 and 11"
fi
