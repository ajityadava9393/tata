#!/bin/bash/

echo "give two number to know max"

read n1
read n2

if [ $n1 -gt $n2 ]
then 

echo "maximum nu is $n1"

else
echo "maximum nu is $n2"

fi
