#!/bin/bash
echo " entre your number to cheak  wheather it is +ve  or -ve or eual to zero"

read num

if [ $num -gt 0 ]

then
echo " $num is +ve "

elif [ $num -lt 0 ]
then
echo " $num is -ve " 
else

echo " $num is = zero(0)"
fi
