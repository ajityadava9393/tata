#!/bin/bash
echo "Enter any number"
read num
for (( i=1; i<=10; i++))
do
        #cube=$i \* $i \* $i
        echo "$num X $i = `expr $num \* $i`"
done
